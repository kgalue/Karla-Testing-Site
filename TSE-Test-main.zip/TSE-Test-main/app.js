const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

app.use(express.static(__dirname + "/public"));

app.get("/main", (req, res) => {
  res.render("main");
});

app.get("/identify", (req, res) => {
  res.render("identifyUser");
});

app.get("/gtmtest", (req, res) => {
  res.render("GTMDriftInstall");
});


app.get("/fastlane", (req, res) => {
  res.render("fastlane");
});

app.get("/ffastlane", (req, res) => {
  res.render("karlaFastlane");
});

app.get("/first", (req, res) => {
  res.render("GTMwithForm1");
});

app.get("/second", (req, res) => {
  res.render("GTMwithForm2");
});

app.get("/form", (req, res) => {
  res.render("simpleFormTest");
});

app.get("/clp", (req, res) => {
  res.render("CLP");
});

app.get("/formly", (req, res) => {
  res.render("leadformlyTest");
});

app.get("/test2", (req, res) => {
  res.render("test2");
});

app.get("/install", (req, res) => {
  res.render("vanillainstall");
});

app.get("/project", (req, res) => {
  res.render("clpprojectmain");
});

app.get("/dFrame", (req, res) => {
  res.render("dFrame");
});

app.get("/train", (req, res) => {
  res.render("erikaTrain");
});

app.get("/param", (req, res) => {
  res.render("paramtest");
});

app.get("/ga", (req, res) => {
  res.render("GATest");
});

app.get("/ga4", (req, res) => {
  res.render("GA4Test");
});

app.get("/index", (req, res) => {
  res.render("index");
});

app.get("/test", (req, res) => {
  res.render("test");
});

app.get("/prev", (req, res) => {
  res.render("fakeWidget");
});

app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`);
});
